public class studentTest {
    private student student;

    @Before
    public void setUp() {
        // Reset the student list before each test
        student.clearStudents();
    }

    @Test
    public void testSaveStudent() {
        student.saveStudent(10111, "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        student foundStudent = student.searchStudent(10111);
        assertNotNull(foundStudent);
        assertEquals(10111, foundStudent.getId());
        assertEquals("J.Bloggs", foundStudent.getName());
    }

    @Test
    public void testSearchStudent() {
        student.saveStudent(10112, "J. Doe", 21, "jdoe@ymail.com", "disd");
        student foundStudent = student.searchStudent(10112);
        assertNotNull(foundStudent);
        assertEquals(10112, foundStudent.getId());
        assertEquals("J. Doe", foundStudent.getName());
    }

    private void assertEquals(int i, Object id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertEquals'");
    }

    private void assertNotNull(student foundStudent) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertNotNull'");
    }

    private void assertEquals(String string, Object name) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertEquals'");
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        Object foundStudent = student.searchStudent(99999);
        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        student.saveStudent(10113, "P. Parker", 20, "spidey@ymail.com", "disn");
        assertTrue(student.deleteStudent(10113));
        assertNull(student.searchStudent(10113));
    }

    private void assertNull(Object searchStudent) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertNull'");
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        assertFalse(student.deleteStudent(99999));
    }

    @Test
    public void testStudentAge_Valid() {
        int age = 19;
        assertTrue(student.isValidAge(age));
    }

    private void assertTrue(Object validAge) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertTrue'");
    }

    @Test
    public void testStudentAge_Invalid() {
        int age = 15;
        assertFalse(student.isValidAge(age));
    }

    @Test
    public void testStudentAge_InvalidCharacter() {
        assertFalse(student.isValidAge("c")); // Assuming isValidAge accepts String
    }

    private void assertFalse(Object validAge) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertFalse'");
    }
}
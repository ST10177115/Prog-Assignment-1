import java.util.ArrayList;
import java.util.Scanner;

public class student {
    private int id;
    private String name;
    private int age;
    private String email;
    private String course;

    // List to hold student records
    private static ArrayList<student> students = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public student(int id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public static void saveStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*********");
        System.out.print("Enter the student id: ");
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();
        int age = promptForValidAge();
        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        student newStudent = new student(id, name, age, email, course);
        students.add(newStudent);
        System.out.println("Student details have been successfully saved.");
        checkMenuOrExit();
    }

    private static int promptForValidAge() {
        int age;
        while (true) {
            System.out.print("Enter the student age: ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) {
                    return age;
                } else {
                    System.out.println("You have entered an incorrect student age!!! Age must be 16 or older.");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please enter a valid number.");
            }
        }
    }

    public static void searchStudent() {
        System.out.print("Enter the student id to search: ");
        int searchId = Integer.parseInt(scanner.nextLine());
        for (student student : students) {
            if (student.id == searchId) {
                System.out.println("STUDENT ID: " + student.id);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.course);
                checkMenuOrExit();
                return;
            }
        }
        System.out.println("Student with Student Id: " + searchId + " was not found!");
        checkMenuOrExit();
    }

    public static void deleteStudent() {
        System.out.print("Enter the student id to delete: ");
        int deleteId = Integer.parseInt(scanner.nextLine());
        for (student student : students) {
            if (student.id == deleteId) {
                System.out.print("Are you sure you want to delete student " + deleteId
                        + " from the system? Yes (y) to delete: ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student with Student Id: " + deleteId + " was deleted!");
                }
                checkMenuOrExit();
                return;
            }
        }
        System.out.println("Student with Student Id: " + deleteId + " was not found!");
        checkMenuOrExit();
    }

    public static void studentReport() {
        System.out.println("STUDENT REPORT:");
        for (student student : students) {
            System.out.println("STUDENT ID: " + student.id);
            System.out.println("STUDENT NAME: " + student.name);
            System.out.println("STUDENT AGE: " + student.age);
            System.out.println("STUDENT EMAIL: " + student.email);
            System.out.println("STUDENT COURSE: " + student.course);
            System.out.println("*********");
        }
        checkMenuOrExit();
    }

    private static void checkMenuOrExit() {
        System.out.println("Enter (1) to launch menu or any other key to exit");
        String choice = scanner.nextLine();
        if (choice.equals("1")) {
            Main.runMenu();
        } else {
            System.out.println("Exiting Student Management Application...");
            System.exit(0);
        }
    }

    public Object isValidAge(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isValidAge'");
    }

    public Object isValidAge(int age2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isValidAge'");
    }

    public Object isValidAge(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isValidAge'");
    }

    public Object deleteStudent(int i) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteStudent'");
    }

    public Object searchStudent(int i) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'searchStudent'");
    }

    public void saveStudent(int i, String string, int j, String string2, String string3) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveStudent'");
    }

    public Object getName() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getName'");
    }

    public Object getId() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getId'");
    }

    public void clearStudents() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'clearStudents'");
    }
}
public class Book {
    // Private attributes for title, author, and availability
    private String title;
    private String author;
    private boolean isAvailable;

    // Constructor to initialize title and author, sets availability to true
    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    // Getter for title
    public String getTitle() {
        return title;
    }

    // Getter for author
    public String getAuthor() {
        return author;
    }

    // Method to check if the book is available
    public boolean isAvailable() {
        return isAvailable;
    }

    // Method to borrow the book
    public void borrow() {
        if (isAvailable) {
            isAvailable = false; // Set availability to false
        } else {
            System.out.println("This book is currently unavailable."); // Handle unavailability
        }
    }

    // Method to return the book
    public void returnBook() {
        isAvailable = true; // Set availability to true
    }

    // Override toString for a readable representation of the book
    @Override
    public String toString() {
        return title + " by " + author + (isAvailable ? " (Available)" : " (Checked Out)");
    }
}

public class EBook extends Book {
    // Private attribute for file format
    private String fileFormat;

    // Constructor to initialize title, author, and file format
    public EBook(String title, String author, String fileFormat) {
        super(title, author); // Call the constructor of the superclass
        this.fileFormat = fileFormat;
    }

    // Getter for file format
    public String getFileFormat() {
        return fileFormat;
    }

    // Override toString to include file format information
    @Override
    public String toString() {
        return super.toString() + " [Format: " + fileFormat + "]";
    }
}

import java.util.ArrayList; // Importing ArrayList for dynamic array functionality
import java.util.List; // Importing List interface

public class Library {
    // Private list to hold books in the library
    private List<Book> books;

    // Constructor to initialize the book list
    public Library() {
        books = new ArrayList<>();
    }

    // Method to add a book to the library
    public void addBook(Book book) {
        books.add(book); // Add the book to the list
    }

    // Method to borrow a book by title
    public void borrowBook(String title) {
        for (Book book : books) { // Loop through the list of books
            if (book.getTitle().equalsIgnoreCase(title)) { // Check for matching title
                book.borrow(); // Attempt to borrow the book
                return; // Exit the method
            }
        }
        System.out.println("Book not found."); // If not found, print message
    }

    // Method to return a book by title
    public void returnBook(String title) {
        for (Book book : books) { // Loop through the list of books
            if (book.getTitle().equalsIgnoreCase(title)) { // Check for matching title
                book.returnBook(); // Attempt to return the book
                return; // Exit the method
            }
        }
        System.out.println("Book not found."); // If not found, print message
    }

    // Method to print a report of all books in the library
    public void printReport() {
        System.out.println("Library Report:"); // Header for the report
        for (Book book : books) { // Loop through the list of books
            System.out.println(book); // Print each book's details
        }
    }
}

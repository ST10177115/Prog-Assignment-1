import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        runMenu();
    }

    public static void runMenu() {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        String choice = scanner.nextLine();

        if (choice.equals("1")) {
            displayMenu();
        } else {
            System.out.println("Exiting Student Management Application...");
            System.exit(0);
        }
    }

    private static void displayMenu() {
        while (true) {
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    student.saveStudent();
                    break;
                case "2":
                    student.searchStudent();
                    break;
                case "3":
                    student.deleteStudent();
                    break;
                case "4":
                    student.studentReport();
                    break;
                case "5":
                    System.out.println("Exiting Student Management Application...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
public class libraryTest {
    public static void main(String[] args) {
        Library library = new Library(); // Create an instance of Library

        // Create book instances
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald");
        EBook ebook1 = new EBook("1984", "George Orwell", "PDF");

        // Add books to the library
        library.addBook(book1);
        library.addBook(ebook1);

        // Print initial report
        library.printReport(); // Should show both books as available

        // Test borrowing a book
        library.borrowBook("1984"); // Borrow the eBook
        library.printReport(); // 1984 should be checked out

        // Test returning a book
        library.returnBook("1984"); // Return the eBook
        library.printReport(); // 1984 should be available again

        // Test borrowing a non-existent book
        library.borrowBook("Unknown Book"); // Should show "Book not found."

        // Test returning a non-existent book
        library.returnBook("Unknown Book"); // Should show "Book not found."
    }
}